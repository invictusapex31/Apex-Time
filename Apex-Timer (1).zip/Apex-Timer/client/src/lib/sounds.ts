// Sound URLs
const SOUND_URLS = {
  bell: "https://assets.mixkit.co/sfx/preview/mixkit-bell-notification-933.mp3",
  digital: "https://assets.mixkit.co/sfx/preview/mixkit-alarm-digital-clock-beep-989.mp3",
  gentle: "https://assets.mixkit.co/sfx/preview/mixkit-interface-option-select-2573.mp3",
  chime: "https://assets.mixkit.co/sfx/preview/mixkit-software-interface-start-2574.mp3"
};

// Audio instances cache
const audioCache: Record<string, HTMLAudioElement> = {};

// Play alarm sound
export const playAlarmSound = (sound: string, volume: number = 0.8): void => {
  try {
    // Get sound URL
    const soundUrl = SOUND_URLS[sound as keyof typeof SOUND_URLS] || SOUND_URLS.bell;
    
    // Create or reuse audio element
    let audio = audioCache[sound];
    if (!audio) {
      audio = new Audio(soundUrl);
      audioCache[sound] = audio;
    }
    
    // Set volume and play
    audio.volume = volume;
    audio.currentTime = 0;
    
    // Create a promise to handle play
    const playPromise = audio.play();
    
    if (playPromise !== undefined) {
      playPromise
        .catch(error => {
          console.error("Error playing sound:", error);
        });
    }
  } catch (error) {
    console.error("Failed to play alarm sound:", error);
  }
};

// Stop all sounds
export const stopAllSounds = (): void => {
  Object.values(audioCache).forEach(audio => {
    audio.pause();
    audio.currentTime = 0;
  });
};

// Test sound (play briefly and then stop)
export const testSound = (sound: string, volume: number = 0.8): void => {
  playAlarmSound(sound, volume);
  
  setTimeout(() => {
    const audio = audioCache[sound];
    if (audio) {
      audio.pause();
      audio.currentTime = 0;
    }
  }, 2000);
};
