import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { playAlarmSound } from "@/lib/sounds";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Settings, 
  Volume2, 
  Clock, 
  Timer as TimerIcon,
  RotateCcw,
  PlayCircle,
  Coffee,
  Moon,
  Save as SaveIcon
} from "lucide-react";

// Define TimerSettings type
interface TimerSettings {
  id: number;
  userId: number | null;
  defaultMinutes: number;
  defaultSeconds: number;
  alarmSound: string;
  volume: number;
  autoStartBreak: boolean;
  timerMode: string;
  pomodoroMinutes: number;
  shortBreakMinutes: number;
  longBreakMinutes: number;
  longBreakInterval: number;
  autoStartPomodoro: boolean;
}

export default function TimerSettings() {
  // General settings
  const [autoStartBreak, setAutoStartBreak] = useState<boolean>(false);
  const [autoStartPomodoro, setAutoStartPomodoro] = useState<boolean>(false);
  const [alarmSound, setAlarmSound] = useState<string>("bell");
  const [volume, setVolume] = useState<number>(80);
  
  // Pomodoro settings
  const [pomodoroMinutes, setPomodoroMinutes] = useState<number>(25);
  const [shortBreakMinutes, setShortBreakMinutes] = useState<number>(5);
  const [longBreakMinutes, setLongBreakMinutes] = useState<number>(15);
  const [longBreakInterval, setLongBreakInterval] = useState<number>(4);
  
  // Countdown default settings
  const [defaultMinutes, setDefaultMinutes] = useState<number>(25);
  const [defaultSeconds, setDefaultSeconds] = useState<number>(0);
  
  const { toast } = useToast();

  // Get timer settings
  const { data: timerSettings, isLoading } = useQuery<TimerSettings>({
    queryKey: ['/api/timer-settings'],
  });

  // Update timer settings
  const updateSettingsMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("PUT", "/api/timer-settings", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/timer-settings'] });
      toast({
        title: "Settings saved",
        description: "Your timer settings have been updated",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to save settings: ${error}`,
        variant: "destructive",
      });
    },
  });

  // Update state from fetched settings
  useEffect(() => {
    if (timerSettings) {
      // General settings
      setAutoStartBreak(timerSettings.autoStartBreak || false);
      setAutoStartPomodoro(timerSettings.autoStartPomodoro || false);
      setAlarmSound(timerSettings.alarmSound || "bell");
      setVolume(timerSettings.volume || 80);
      
      // Pomodoro settings
      setPomodoroMinutes(timerSettings.pomodoroMinutes || 25);
      setShortBreakMinutes(timerSettings.shortBreakMinutes || 5);
      setLongBreakMinutes(timerSettings.longBreakMinutes || 15);
      setLongBreakInterval(timerSettings.longBreakInterval || 4);
      
      // Countdown default settings
      setDefaultMinutes(timerSettings.defaultMinutes || 25);
      setDefaultSeconds(timerSettings.defaultSeconds || 0);
    }
  }, [timerSettings]);
  
  // Save all settings at once
  const handleSaveAllSettings = () => {
    const allSettings = {
      // General settings
      autoStartBreak,
      autoStartPomodoro,
      alarmSound,
      volume,
      
      // Pomodoro settings
      pomodoroMinutes,
      shortBreakMinutes,
      longBreakMinutes,
      longBreakInterval,
      
      // Countdown default settings
      defaultMinutes,
      defaultSeconds
    };
    
    updateSettingsMutation.mutate(allSettings);
  };

  // Handle auto start break toggle
  const handleAutoStartBreakChange = (checked: boolean) => {
    setAutoStartBreak(checked);
    updateSettingsMutation.mutate({ autoStartBreak: checked });
  };
  
  // Handle auto start pomodoro toggle
  const handleAutoStartPomodoroChange = (checked: boolean) => {
    setAutoStartPomodoro(checked);
    updateSettingsMutation.mutate({ autoStartPomodoro: checked });
  };

  // Handle alarm sound change
  const handleAlarmSoundChange = (value: string) => {
    setAlarmSound(value);
    updateSettingsMutation.mutate({ alarmSound: value });
  };

  // Handle volume change
  const handleVolumeChange = (value: number[]) => {
    const newVolume = value[0];
    setVolume(newVolume);
    updateSettingsMutation.mutate({ volume: newVolume });
  };
  
  // Handle pomodoro minutes change
  const handlePomodoroMinutesChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    if (isNaN(value) || value < 1) {
      setPomodoroMinutes(1);
      updateSettingsMutation.mutate({ pomodoroMinutes: 1 });
    } else if (value > 60) {
      setPomodoroMinutes(60);
      updateSettingsMutation.mutate({ pomodoroMinutes: 60 });
    } else {
      setPomodoroMinutes(value);
      updateSettingsMutation.mutate({ pomodoroMinutes: value });
    }
  };
  
  // Handle short break minutes change
  const handleShortBreakMinutesChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    if (isNaN(value) || value < 1) {
      setShortBreakMinutes(1);
      updateSettingsMutation.mutate({ shortBreakMinutes: 1 });
    } else if (value > 30) {
      setShortBreakMinutes(30);
      updateSettingsMutation.mutate({ shortBreakMinutes: 30 });
    } else {
      setShortBreakMinutes(value);
      updateSettingsMutation.mutate({ shortBreakMinutes: value });
    }
  };
  
  // Handle long break minutes change
  const handleLongBreakMinutesChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    if (isNaN(value) || value < 1) {
      setLongBreakMinutes(1);
      updateSettingsMutation.mutate({ longBreakMinutes: 1 });
    } else if (value > 60) {
      setLongBreakMinutes(60);
      updateSettingsMutation.mutate({ longBreakMinutes: 60 });
    } else {
      setLongBreakMinutes(value);
      updateSettingsMutation.mutate({ longBreakMinutes: value });
    }
  };
  
  // Handle long break interval change
  const handleLongBreakIntervalChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    if (isNaN(value) || value < 1) {
      setLongBreakInterval(1);
      updateSettingsMutation.mutate({ longBreakInterval: 1 });
    } else if (value > 10) {
      setLongBreakInterval(10);
      updateSettingsMutation.mutate({ longBreakInterval: 10 });
    } else {
      setLongBreakInterval(value);
      updateSettingsMutation.mutate({ longBreakInterval: value });
    }
  };
  
  // Handle default minutes change
  const handleDefaultMinutesChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    if (isNaN(value) || value < 0) {
      setDefaultMinutes(0);
      updateSettingsMutation.mutate({ defaultMinutes: 0 });
    } else if (value > 1440) { // 24 hours max
      setDefaultMinutes(1440);
      updateSettingsMutation.mutate({ defaultMinutes: 1440 });
    } else {
      setDefaultMinutes(value);
      updateSettingsMutation.mutate({ defaultMinutes: value });
    }
  };
  
  // Handle default seconds change
  const handleDefaultSecondsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    if (isNaN(value) || value < 0) {
      setDefaultSeconds(0);
      updateSettingsMutation.mutate({ defaultSeconds: 0 });
    } else if (value > 59) {
      setDefaultSeconds(59);
      updateSettingsMutation.mutate({ defaultSeconds: 59 });
    } else {
      setDefaultSeconds(value);
      updateSettingsMutation.mutate({ defaultSeconds: value });
    }
  };

  // Test sound
  const handleTestSound = () => {
    playAlarmSound(alarmSound, volume / 100);
  };

  // Reset to defaults
  const handleResetToDefaults = () => {
    // Pomodoro defaults
    setPomodoroMinutes(25);
    setShortBreakMinutes(5);
    setLongBreakMinutes(15);
    setLongBreakInterval(4);
    setAutoStartBreak(false);
    setAutoStartPomodoro(false);
    
    // Reset countdown defaults
    setDefaultMinutes(25);
    setDefaultSeconds(0);
    
    // Reset sound settings
    setAlarmSound("bell");
    setVolume(80);
    
    // Apply all updates to server
    updateSettingsMutation.mutate({
      pomodoroMinutes: 25,
      shortBreakMinutes: 5,
      longBreakMinutes: 15,
      longBreakInterval: 4,
      autoStartBreak: false,
      autoStartPomodoro: false,
      defaultMinutes: 25,
      defaultSeconds: 0,
      alarmSound: "bell",
      volume: 80,
      timerMode: "pomodoro"
    });
    
    toast({
      title: "Settings reset",
      description: "All timer settings have been reset to defaults",
    });
  };

  return (
    <Card className="glass-effect bg-background/40 backdrop-blur-lg shadow-premium border border-primary/10 rounded-xl overflow-hidden">
      <div className="absolute top-0 right-0 w-1/3 h-full bg-premium-gradient opacity-5 blur-2xl"></div>
      <CardContent className="p-6 relative z-10">
        <h2 className="text-xl font-bold tracking-tight mb-5 flex items-center premium-text">
          <Settings className="h-5 w-5 mr-2 text-primary" />
          Timer Settings
          <div className="ml-2 inline-flex h-5 items-center rounded-full border border-primary/20 px-2">
            <span className="text-xs text-muted-foreground premium-text">v1.0</span>
          </div>
        </h2>
        
        <Tabs defaultValue="pomodoro" className="w-full">
          <TabsList className="w-full mb-6 bg-background/50 border border-primary/10 rounded-full p-1 text-foreground shadow-inner">
            <TabsTrigger 
              value="pomodoro" 
              className="flex items-center data-[state=active]:bg-premium-gradient data-[state=active]:text-primary-foreground data-[state=active]:shadow rounded-full premium-text py-1.5"
            >
              <TimerIcon className="h-3.5 w-3.5 mr-1.5" /> 
              <span className="premium-text">Pomodoro</span>
            </TabsTrigger>
            <TabsTrigger 
              value="timer" 
              className="flex items-center data-[state=active]:bg-premium-gradient data-[state=active]:text-primary-foreground data-[state=active]:shadow rounded-full premium-text py-1.5"
            >
              <Clock className="h-3.5 w-3.5 mr-1.5" /> 
              <span className="premium-text">Timer</span>
            </TabsTrigger>
            <TabsTrigger 
              value="sound" 
              className="flex items-center data-[state=active]:bg-premium-gradient data-[state=active]:text-primary-foreground data-[state=active]:shadow rounded-full premium-text py-1.5"
            >
              <Volume2 className="h-3.5 w-3.5 mr-1.5" /> 
              <span className="premium-text">Sound</span>
            </TabsTrigger>
          </TabsList>
          
          {/* Pomodoro Settings */}
          <TabsContent value="pomodoro" className="space-y-4">
            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="pomodoro-minutes" className="premium-label flex items-center text-sm font-medium mb-1">
                  <div className="flex h-6 w-6 items-center justify-center rounded-full bg-primary/10 mr-2">
                    <PlayCircle className="h-3.5 w-3.5 text-primary" />
                  </div>
                  <span className="premium-text">Focus Time (min)</span>
                </Label>
                <Input
                  id="pomodoro-minutes"
                  type="number" 
                  min="1"
                  max="60"
                  value={pomodoroMinutes}
                  onChange={handlePomodoroMinutesChange}
                  className="timer-input w-full bg-background/50 border-primary/20 focus:border-primary/40 shadow-inner text-foreground"
                />
                <p className="text-xs text-muted-foreground px-1">Recommended: 25 min</p>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="short-break-minutes" className="premium-label flex items-center text-sm font-medium mb-1">
                  <div className="flex h-6 w-6 items-center justify-center rounded-full bg-accent/10 mr-2">
                    <Coffee className="h-3.5 w-3.5 text-accent" />
                  </div>
                  <span className="premium-text">Short Break (min)</span>
                </Label>
                <Input
                  id="short-break-minutes"
                  type="number" 
                  min="1"
                  max="30"
                  value={shortBreakMinutes}
                  onChange={handleShortBreakMinutesChange}
                  className="timer-input w-full bg-background/50 border-accent/20 focus:border-accent/40 shadow-inner text-foreground"
                />
                <p className="text-xs text-muted-foreground px-1">Recommended: 5 min</p>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-6 mt-3">
              <div className="space-y-2">
                <Label htmlFor="long-break-minutes" className="premium-label flex items-center text-sm font-medium mb-1">
                  <div className="flex h-6 w-6 items-center justify-center rounded-full bg-purple-400/10 mr-2">
                    <Moon className="h-3.5 w-3.5 text-purple-400" />
                  </div>
                  <span className="premium-text">Long Break (min)</span>
                </Label>
                <Input
                  id="long-break-minutes"
                  type="number" 
                  min="1"
                  max="60"
                  value={longBreakMinutes}
                  onChange={handleLongBreakMinutesChange}
                  className="timer-input w-full bg-background/50 border-purple-400/20 focus:border-purple-400/40 shadow-inner text-foreground"
                />
                <p className="text-xs text-muted-foreground px-1">Recommended: 15 min</p>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="long-break-interval" className="premium-label flex items-center text-sm font-medium mb-1">
                  <div className="flex h-6 w-6 items-center justify-center rounded-full bg-primary/10 mr-2">
                    <RotateCcw className="h-3.5 w-3.5 text-primary" />
                  </div>
                  <span className="premium-text">Long Break After (cycles)</span>
                </Label>
                <Input
                  id="long-break-interval"
                  type="number" 
                  min="1"
                  max="10"
                  value={longBreakInterval}
                  onChange={handleLongBreakIntervalChange}
                  className="timer-input w-full bg-background/50 border-primary/20 focus:border-primary/40 shadow-inner text-foreground"
                />
                <p className="text-xs text-muted-foreground px-1">Recommended: 4 cycles</p>
              </div>
            </div>
            
            <div className="bg-background/30 rounded-xl p-4 border border-primary/10 mt-4">
              <h3 className="text-sm font-semibold premium-text mb-3">Automatic Settings</h3>
              
              <div className="flex items-center justify-between py-2 border-b border-primary/5">
                <Label htmlFor="auto-start-break" className="premium-label flex items-center cursor-pointer">
                  <div className="flex h-6 w-6 items-center justify-center rounded-full bg-accent/10 mr-2">
                    <Coffee className="h-3.5 w-3.5 text-accent" />
                  </div>
                  <div className="flex flex-col">
                    <span className="premium-text text-sm">Auto-start breaks</span>
                    <span className="text-xs text-muted-foreground">Timer will start breaks automatically</span>
                  </div>
                </Label>
                <Switch
                  id="auto-start-break"
                  checked={autoStartBreak}
                  onCheckedChange={handleAutoStartBreakChange}
                  className="data-[state=checked]:bg-premium-gradient"
                />
              </div>
              
              <div className="flex items-center justify-between py-2 mt-2">
                <Label htmlFor="auto-start-pomodoro" className="premium-label flex items-center cursor-pointer">
                  <div className="flex h-6 w-6 items-center justify-center rounded-full bg-primary/10 mr-2">
                    <PlayCircle className="h-3.5 w-3.5 text-primary" />
                  </div>
                  <div className="flex flex-col">
                    <span className="premium-text text-sm">Auto-start next pomodoro</span>
                    <span className="text-xs text-muted-foreground">Timer will start next pomodoro after break</span>
                  </div>
                </Label>
                <Switch
                  id="auto-start-pomodoro"
                  checked={autoStartPomodoro}
                  onCheckedChange={handleAutoStartPomodoroChange}
                  className="data-[state=checked]:bg-premium-gradient"
                />
              </div>
            </div>
          </TabsContent>
          
          {/* Countdown Timer Settings */}
          <TabsContent value="timer" className="space-y-4">
            <div className="bg-background/30 rounded-xl p-5 border border-primary/10 mb-2">
              <h3 className="text-sm font-semibold premium-text mb-3">Default Timer</h3>
              
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="default-minutes" className="premium-label flex items-center text-sm font-medium mb-1">
                    <div className="flex h-6 w-6 items-center justify-center rounded-full bg-primary/10 mr-2">
                      <Clock className="h-3.5 w-3.5 text-primary" />
                    </div>
                    <span className="premium-text">Minutes</span>
                  </Label>
                  <Input
                    id="default-minutes"
                    type="number" 
                    min="0"
                    max="1440"
                    value={defaultMinutes}
                    onChange={handleDefaultMinutesChange}
                    className="timer-input w-full bg-background/50 border-primary/20 focus:border-primary/40 shadow-inner text-foreground"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="default-seconds" className="premium-label flex items-center text-sm font-medium mb-1">
                    <div className="flex h-6 w-6 items-center justify-center rounded-full bg-primary/10 mr-2">
                      <Clock className="h-3.5 w-3.5 text-primary" />
                    </div>
                    <span className="premium-text">Seconds</span>
                  </Label>
                  <Input
                    id="default-seconds"
                    type="number" 
                    min="0"
                    max="59"
                    value={defaultSeconds}
                    onChange={handleDefaultSecondsChange}
                    className="timer-input w-full bg-background/50 border-primary/20 focus:border-primary/40 shadow-inner text-foreground"
                  />
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-3">Set default countdown time (up to 24 hours)</p>
            </div>
          </TabsContent>
          
          {/* Sound Settings */}
          <TabsContent value="sound" className="space-y-4">
            <div className="bg-background/30 rounded-xl p-5 border border-primary/10">
              <h3 className="text-sm font-semibold premium-text mb-4 flex items-center">
                <Volume2 className="h-4 w-4 mr-2 text-primary" />
                Audio Configuration
              </h3>
              
              <div className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="alarm-sound" className="premium-label block text-sm font-medium mb-1">
                    <span className="premium-text">Sound Theme</span>
                  </Label>
                  <Select value={alarmSound} onValueChange={handleAlarmSoundChange}>
                    <SelectTrigger className="w-full bg-background/50 border-primary/20 focus:border-primary/40 shadow-inner text-foreground focus:ring-primary/30">
                      <SelectValue placeholder="Select a sound" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="bell">
                        <div className="flex items-center">
                          <div className="w-2 h-2 rounded-full bg-primary mr-2"></div>
                          Bell
                        </div>
                      </SelectItem>
                      <SelectItem value="digital">
                        <div className="flex items-center">
                          <div className="w-2 h-2 rounded-full bg-accent mr-2"></div>
                          Digital
                        </div>
                      </SelectItem>
                      <SelectItem value="gentle">
                        <div className="flex items-center">
                          <div className="w-2 h-2 rounded-full bg-purple-400 mr-2"></div>
                          Gentle
                        </div>
                      </SelectItem>
                      <SelectItem value="chime">
                        <div className="flex items-center">
                          <div className="w-2 h-2 rounded-full bg-emerald-400 mr-2"></div>
                          Chime
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center justify-between mb-2">
                    <Label htmlFor="volume-control" className="premium-label block text-sm font-medium">
                      <span className="premium-text">Volume</span>
                    </Label>
                    <span className="text-sm font-medium text-primary">{volume}%</span>
                  </div>
                  <Slider
                    id="volume-control"
                    min={0}
                    max={100}
                    step={1}
                    value={[volume]}
                    onValueChange={handleVolumeChange}
                    className="w-full"
                  />
                </div>
                
                <div className="pt-2">
                  <Button
                    variant="outline"
                    className="w-full button-bounce border-primary/20 hover:bg-background/80 hover:border-primary/40 transition-all flex items-center justify-center"
                    onClick={handleTestSound}
                  >
                    <Volume2 className="h-4 w-4 mr-2 text-primary" /> 
                    <span className="premium-text">Test Sound</span>
                  </Button>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
        
        <div className="pt-4 mt-6 border-t border-primary/10 flex flex-col gap-4">
          <div className="flex justify-between items-center">
            <Button
              variant="ghost"
              size="sm"
              className="text-xs text-muted-foreground hover:text-foreground button-bounce"
              onClick={handleResetToDefaults}
            >
              <RotateCcw className="h-3 w-3 mr-1.5" /> Reset to defaults
            </Button>
            
            <Button 
              variant="default"
              size="sm"
              className="bg-primary text-primary-foreground hover:bg-primary/90 shadow button-bounce"
              onClick={handleSaveAllSettings}
            >
              <SaveIcon className="h-3.5 w-3.5 mr-1.5" /> Save all settings
            </Button>
          </div>
          
          <div className="flex justify-between items-center">
            <p className="text-xs text-muted-foreground">INVICTUS APEX &copy; {new Date().getFullYear()}</p>
            {updateSettingsMutation.isPending && (
              <p className="text-xs text-primary animate-pulse">Saving settings...</p>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
