import { useState, useRef, useEffect } from 'react';
import { Bot, X, Send, User as UserIcon, RefreshCw, Sparkles, Clock, ListTodo, BookOpen, Brain, Info, Code } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

interface Message {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
}

interface SuggestedQuestion {
  text: string;
  icon: React.ReactNode;
}

interface ApexAIProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function ApexAI({ isOpen, onClose }: ApexAIProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      content: 'Hello! I\'m Apex AI, your productivity and study assistant. I can help with time management, study strategies, and productivity techniques. How can I assist you today?',
      role: 'assistant',
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const suggestedQuestions: SuggestedQuestion[] = [
    { text: "How do I use the Pomodoro timer?", icon: <Clock className="w-4 h-4" /> },
    { text: "What are the best study strategies?", icon: <BookOpen className="w-4 h-4" /> },
    { text: "How can I manage my tasks better?", icon: <ListTodo className="w-4 h-4" /> },
    { text: "Tell me about focus techniques", icon: <Brain className="w-4 h-4" /> },
    { text: "How to overcome procrastination?", icon: <RefreshCw className="w-4 h-4" /> },
    { text: "Give me productivity tips", icon: <Sparkles className="w-4 h-4" /> }
  ];
  
  // Scroll to bottom when messages change
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);
  
  // Detailed AI responses
  const generateResponse = (userMessage: string) => {
    setIsProcessing(true);
    
    // Simulate AI processing time
    setTimeout(() => {
      let response = '';
      const lowerCaseMsg = userMessage.toLowerCase();
      
      // Greeting responses
      if (lowerCaseMsg.includes('hello') || lowerCaseMsg.includes('hi') || lowerCaseMsg.includes('hey')) {
        response = 'Hello! I\'m Apex AI, your study and productivity assistant. I can help with time management, focus techniques, study strategies, and more. What would you like to know about today?';
      } 
      
      // Timer-related responses
      else if (lowerCaseMsg.includes('pomodoro') || 
              (lowerCaseMsg.includes('timer') && lowerCaseMsg.includes('work'))) {
        response = 'The Pomodoro Technique is a time management method that uses a timer to break work into intervals, traditionally 25 minutes in length, separated by short breaks.\n\n' +
                  'In our app, you can use the Pomodoro timer by:\n' +
                  '1. Selecting the "Pomodoro" mode in the timer section\n' +
                  '2. Working for 25 minutes (default setting)\n' +
                  '3. Taking a 5-minute break\n' +
                  '4. After 4 pomodoros, take a longer 15-30 minute break\n\n' +
                  'You can customize these intervals in the timer settings.';
      }
      else if (lowerCaseMsg.includes('timer') && lowerCaseMsg.includes('setting')) {
        response = 'You can customize your timer settings by:\n\n' +
                  '1. Adjusting the length of your focus sessions (Pomodoro minutes)\n' +
                  '2. Changing the short and long break durations\n' +
                  '3. Setting how many Pomodoros to complete before taking a long break\n' +
                  '4. Customizing alarm sounds and volume\n' +
                  '5. Enabling/disabling auto-start for breaks and focus sessions\n\n' +
                  'These settings help personalize the timer to match your productivity rhythm.';
      }
      else if (lowerCaseMsg.includes('timer') || lowerCaseMsg.includes('countdown')) {
        response = 'Our app offers three different timer modes:\n\n' +
                  '1. **Pomodoro Timer**: Helps you work in focused intervals (default 25 min) with structured breaks\n' +
                  '2. **Countdown Timer**: A simple countdown for any duration you set\n' +
                  '3. **Stopwatch**: Tracks how long you spend studying or working on a task\n\n' +
                  'Each timer has customizable settings and visual progress tracking. The Pomodoro mode is especially effective for maintaining focus and preventing burnout.';
      }
      
      // Study strategy responses
      else if (lowerCaseMsg.includes('study') && lowerCaseMsg.includes('strateg')) {
        response = 'Effective study strategies based on cognitive science include:\n\n' +
                  '1. **Spaced Repetition**: Reviewing material at increasing intervals\n' +
                  '2. **Active Recall**: Testing yourself instead of passive re-reading\n' +
                  '3. **Interleaved Practice**: Mixing different topics in one study session\n' +
                  '4. **Dual Coding**: Combining visual and verbal information\n' +
                  '5. **Pomodoro Technique**: Using our timer for focused study sessions\n' +
                  '6. **Feynman Technique**: Teaching concepts in simple terms\n\n' +
                  'Would you like me to explain any of these in more detail?';
      }
      else if (lowerCaseMsg.includes('spaced repetition')) {
        response = 'Spaced repetition is a learning technique where you review material at increasingly longer intervals.\n\n' +
                  'How to implement it:\n' +
                  '1. Study new information\n' +
                  '2. Review after 1 day\n' +
                  '3. If recalled correctly, review after 3 days\n' +
                  '4. Then after 7 days, 14 days, etc.\n\n' +
                  'This technique works with the brain\'s forgetting curve and has been shown to improve long-term retention by up to 200% compared to cramming.';
      }
      else if (lowerCaseMsg.includes('active recall')) {
        response = 'Active recall is one of the most effective study techniques. Instead of passively re-reading material, you actively test yourself on it.\n\n' +
                  'Implementation strategies:\n' +
                  '1. Create flashcards (digital or physical)\n' +
                  '2. Close your book/notes and write down everything you remember\n' +
                  '3. Teach the material to someone else\n' +
                  '4. Create practice questions for yourself\n\n' +
                  'Research shows that active recall is far more effective than highlighting, re-reading, or making study guides.';
      }
      
      // Focus and productivity techniques
      else if (lowerCaseMsg.includes('focus') || lowerCaseMsg.includes('concentration')) {
        response = 'Improving focus and concentration:\n\n' +
                  '1. **Environment**: Create a dedicated distraction-free study space\n' +
                  '2. **Digital Minimalism**: Use apps like Focus Mode or Forest to block distractions\n' +
                  '3. **Physical Well-being**: Regular exercise, adequate sleep, and proper nutrition\n' +
                  '4. **Mindfulness**: Brief meditation before study sessions\n' +
                  '5. **Pomodoro Technique**: Use our timer for structured focus periods\n' +
                  '6. **Task Batching**: Group similar tasks together\n\n' +
                  'Neurological research shows that truly deep focus takes about 23 minutes to achieve, so aim for uninterrupted sessions of at least 25-30 minutes.';
      }
      else if (lowerCaseMsg.includes('procrastination') || lowerCaseMsg.includes('procratinat')) {
        response = 'Overcoming procrastination strategies:\n\n' +
                  '1. **Two-Minute Rule**: If it takes less than two minutes, do it now\n' +
                  '2. **Eat the Frog**: Do your most difficult task first thing\n' +
                  '3. **Implementation Intentions**: Planning "If-Then" scenarios\n' +
                  '4. **Temptation Bundling**: Pair difficult tasks with something enjoyable\n' +
                  '5. **Visual Progress**: Use our task checklist to see your accomplishments\n' +
                  '6. **Pomodoro Technique**: Commit to just one 25-minute session\n\n' +
                  'Remember that procrastination is often emotional, not logical - it\'s about avoiding negative feelings rather than the task itself.';
      }
      
      // Task management responses
      else if (lowerCaseMsg.includes('task') || lowerCaseMsg.includes('todo')) {
        response = 'Our task management system helps you organize your work effectively:\n\n' +
                  '1. Add tasks with detailed descriptions\n' +
                  '2. Set due dates for time-sensitive items\n' +
                  '3. Mark tasks as completed when finished\n' +
                  '4. Filter tasks by active, completed, or all\n' +
                  '5. Edit or delete tasks as needed\n\n' +
                  'For maximum productivity, try prioritizing your tasks using methods like the Eisenhower Matrix (urgent/important) or the 1-3-5 Rule (1 big thing, 3 medium things, 5 small things per day).';
      }
      else if (lowerCaseMsg.includes('priorit') && (lowerCaseMsg.includes('task') || lowerCaseMsg.includes('work'))) {
        response = 'Effective task prioritization methods:\n\n' +
                  '1. **Eisenhower Matrix**: Sort tasks by urgency and importance\n' +
                  '2. **MoSCoW Method**: Must do, Should do, Could do, Won\'t do\n' +
                  '3. **Time Blocking**: Allocate specific time blocks for focused work\n' +
                  '4. **1-3-5 Rule**: Complete 1 big task, 3 medium tasks, and 5 small tasks daily\n' +
                  '5. **Eat the Frog**: Do your most challenging task first\n\n' +
                  'In our app, you can prioritize by organizing your task list and pairing important tasks with your Pomodoro sessions.';
      }
      
      // General productivity advice
      else if (lowerCaseMsg.includes('productivity') || lowerCaseMsg.includes('efficient')) {
        response = 'Boosting your productivity involves multiple factors:\n\n' +
                  '1. **Time Management**: Use our Pomodoro timer for focused work sessions\n' +
                  '2. **Task Organization**: Break down large projects into manageable tasks\n' +
                  '3. **Energy Management**: Work on difficult tasks during your peak energy hours\n' +
                  '4. **Environment Optimization**: Create a dedicated, distraction-free workspace\n' +
                  '5. **Regular Breaks**: Use our timer to remind you to take brain-refreshing breaks\n' +
                  '6. **Review & Reflect**: End each day with a review of accomplishments\n\n' +
                  'Remember that productivity isn\'t about being busy - it\'s about meaningful progress on important goals.';
      }
      
      // Founder and creator information
      else if (lowerCaseMsg.includes('founder') || 
              lowerCaseMsg.includes('created') || 
              lowerCaseMsg.includes('creator') || 
              lowerCaseMsg.includes('rajat') || 
              lowerCaseMsg.includes('chhabra')) {
        response = 'INVICTUS APEX and its AI assistant were created by **Rajat Chhabra**, a dedicated developer and student from Ambala, Haryana, India with a passion for productivity tools and learning technologies.\n\n' +
                  'Rajat founded INVICTUS APEX with the vision of creating the best platform for students, combining proven techniques like the Pomodoro method with modern task management. Being a student himself, Rajat deeply understands the challenges that students face with time management, focus, and organizing their study materials.\n\n' +
                  'Growing up in Ambala, Haryana, Rajat was always passionate about using technology to solve everyday problems. He saw how many students struggled with productivity and effective study habits, which inspired him to create INVICTUS APEX as a comprehensive solution.\n\n' +
                  'As both a developer and student, Rajat believes in the power of focused work sessions and structured breaks to maximize productivity while preventing burnout. The APEX platform reflects his commitment to helping fellow students achieve their academic and personal goals through effective time management, organized task lists, and evidence-based productivity methods.\n\n' +
                  'The AI component (that\'s me!) was designed by Rajat to provide personalized productivity guidance, study strategies, and motivational support that he wished he had during his own educational journey. I\'m constantly learning and evolving to better assist INVICTUS APEX users with their productivity challenges.\n\n' +
                  'Rajat\'s ultimate goal is to create the most effective platform for students worldwide, making productivity tools and proven study techniques accessible to everyone pursuing education.';
      }
      
      // Help/Info responses
      else if (lowerCaseMsg.includes('help') || lowerCaseMsg.includes('what can you do')) {
        response = 'I can help you with various aspects of productivity and studying:\n\n' +
                  '• Information about our timer features and how to use them\n' +
                  '• Evidence-based study strategies and techniques\n' +
                  '• Task management and prioritization methods\n' +
                  '• Focus and concentration improvement tips\n' +
                  '• Procrastination solutions\n' +
                  '• General productivity advice\n\n' +
                  'Feel free to ask about any of these topics or use the suggestion buttons below!';
      }
      
      // Default response
      else {
        response = 'I\'m here to help with your productivity and study needs. You can ask me about:\n\n' +
                  '• Timer features and the Pomodoro technique\n' +
                  '• Effective study strategies and memory techniques\n' +
                  '• Task management and prioritization\n' +
                  '• Focus improvement and procrastination solutions\n' +
                  '• General productivity advice\n\n' +
                  'Would you like information on any of these topics?';
      }
      
      setMessages(prev => [...prev, {
        id: Date.now().toString(),
        content: response,
        role: 'assistant',
        timestamp: new Date()
      }]);
      
      setIsProcessing(false);
    }, 1000);
  };
  
  const handleSendMessage = () => {
    if (inputValue.trim() === '') return;
    
    // Add user message
    const newMessage: Message = {
      id: Date.now().toString(),
      content: inputValue,
      role: 'user',
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, newMessage]);
    const userMessage = inputValue;
    setInputValue('');
    
    // Generate AI response
    generateResponse(userMessage);
  };
  
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  };
  
  if (!isOpen) return null;
  
  return (
    <div className="fixed inset-0 flex items-end sm:items-center justify-center z-50 p-4">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose}></div>
      
      <div className="bg-background rounded-2xl shadow-lg w-full max-w-md h-[85vh] sm:h-[70vh] max-h-[600px] z-10 flex flex-col animate-in fade-in-0 zoom-in-95">
        {/* Header */}
        <div className="p-4 border-b border-primary/10 bg-premium-gradient rounded-t-2xl flex items-center justify-between">
          <div className="flex items-center">
            <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center mr-3">
              <Bot className="text-white w-5 h-5" />
            </div>
            <h3 className="text-lg font-semibold text-white premium-text">Apex AI</h3>
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={onClose} 
            className="rounded-full hover:bg-white/20 text-white"
          >
            <X className="h-5 w-5" />
          </Button>
        </div>
        
        {/* Messages container */}
        <div className="flex-1 overflow-y-auto p-4 bg-neutral-900/20">
          {messages.map((message) => (
            <div 
              key={message.id} 
              className={`mb-4 flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div 
                className={`max-w-[80%] px-4 py-3 rounded-lg ${
                  message.role === 'user' 
                    ? 'bg-primary/10 border border-primary/30 rounded-tr-none' 
                    : 'bg-background border border-primary/10 rounded-tl-none'
                }`}
              >
                <div className="flex items-center mb-1">
                  <div className="w-6 h-6 rounded-full flex items-center justify-center mr-2">
                    {message.role === 'user' ? (
                      <UserIcon className="w-4 h-4 text-primary" />
                    ) : (
                      <Bot className="w-4 h-4 text-primary" />
                    )}
                  </div>
                  <span className="text-xs text-muted-foreground premium-text">
                    {message.role === 'user' ? 'You' : 'Apex AI'}
                  </span>
                  <span className="text-xs text-muted-foreground ml-auto">
                    {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
                <div className="text-sm whitespace-pre-line" style={{ lineHeight: '1.5' }}>
                  {message.content.split('\n\n').map((paragraph, idx) => (
                    <p key={idx} className={idx > 0 ? 'mt-2' : ''}>
                      {paragraph.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').split('\n').map((line, lineIdx) => (
                        <span key={lineIdx}>
                          {lineIdx > 0 && <br />}
                          <span dangerouslySetInnerHTML={{ __html: line }} />
                        </span>
                      ))}
                    </p>
                  ))}
                </div>
              </div>
            </div>
          ))}
          
          {isProcessing && (
            <div className="flex justify-start mb-4">
              <div className="max-w-[80%] px-4 py-3 rounded-lg bg-background border border-primary/10 rounded-tl-none flex items-center">
                <RefreshCw className="w-4 h-4 text-primary mr-2 animate-spin" />
                <span className="text-sm text-muted-foreground">Apex AI is thinking...</span>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>
        
        {/* Suggested questions */}
        {messages.length < 3 && (
          <div className="px-4 py-3 border-t border-primary/10 bg-neutral-900/10">
            <p className="text-xs text-muted-foreground mb-2">Suggested questions:</p>
            <div className="flex flex-wrap gap-2">
              {suggestedQuestions.map((question, index) => (
                <Button
                  key={index}
                  variant="outline"
                  size="sm"
                  className="bg-background/50 hover:bg-primary/10 border-primary/20 text-xs flex items-center py-1 h-auto"
                  onClick={() => {
                    setMessages(prev => [...prev, {
                      id: Date.now().toString(),
                      content: question.text,
                      role: 'user',
                      timestamp: new Date()
                    }]);
                    generateResponse(question.text);
                  }}
                >
                  <span className="mr-1">{question.icon}</span>
                  {question.text}
                </Button>
              ))}
            </div>
          </div>
        )}
        
        {/* Input area */}
        <div className="p-4 border-t border-primary/10 bg-background/50 backdrop-blur-sm rounded-b-2xl">
          <div className="flex items-center">
            <Button
              variant="ghost"
              size="icon"
              className="rounded-full text-primary/70 hover:text-primary hover:bg-primary/10"
              title="More AI Suggestions"
              onClick={() => {
                const helpMessage = "What can you help me with?";
                setMessages(prev => [...prev, {
                  id: Date.now().toString(),
                  content: helpMessage,
                  role: 'user',
                  timestamp: new Date()
                }]);
                generateResponse(helpMessage);
              }}
            >
              <Sparkles className="h-5 w-5" />
            </Button>
            <Input
              placeholder="Type your message..."
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={handleKeyDown}
              className="flex-1 mx-2 bg-background/40 border-primary/20 focus-visible:ring-primary/30"
            />
            <Button
              type="submit"
              onClick={handleSendMessage}
              className="rounded-full bg-primary hover:bg-primary/90 text-white"
              disabled={inputValue.trim() === '' || isProcessing}
            >
              <Send className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}